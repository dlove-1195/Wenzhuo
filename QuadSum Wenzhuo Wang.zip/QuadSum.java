import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * Program to find the four distinct integers that sum up to a certain number.
 *
 * @author Wenzhuo Wang
 */
public final class QuadSum {

    /**
     * Default constructor--private to prevent instantiation.
     */
    private QuadSum() {
        // no code needed here
    }

    private static boolean uniqueVal(int val1, int val2, int val3, int val4) {
        return (val1 != val2) && (val1 != val2) && (val1 != val3)
                && (val1 != val4) && (val2 != val3) && (val2 != val4)
                && (val3 != val4);
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {
        HashMap<Integer, Integer> m = new HashMap<>();
	ArrayList<Integer> a = new ArrayList<>();
	Scanner sc = new Scanner(new File(args[0]));
        int sum = Integer.parseInt(args[1]);
        boolean has = false;
        while (sc.hasNextLine()) {
            a.add(Integer.parseInt(sc.nextLine()));
        }
        search: {
            for (int j = 0; j < a.size(); j++) {
                for (int k = j + 1; k < a.size(); k++) {
                    int val1 = a.get(j);
                    int val2 = a.get(k);
                    if (!m.containsKey(val1 + val2)) {
                        m.put(val1 + val2, val1);
                    }
                    if (m.containsKey(sum - val1 - val2) && uniqueVal(val1,
                            val2, m.get(sum - val1 - val2),
                            sum - m.get(sum - val1 - val2) - val1 - val2)) {
                        System.out.println("Find unique four values: (" + val1
                                + ", " + val2 + ", " + m.get(sum - val1 - val2)
                                + ", " + (sum - m.get(sum - val1 - val2) - val1
                                        - val2) + ") that add up to " + sum);
                        has = true;
                        break search;
                    }
                }

            }
        }
        if (!has) {
            System.out.println(
                    "There is no four distict number that sums to " + sum);
        }
    }
}

