The program is written by java. To run the program, you need to 
1)get into stdlinux
2)unzip the zip file 
3)type "javac QuadSum.java" to compile
4)type "java QuadSum dataX sumVal" 
where dataX is the name of file which contains lines of integer and sumVal is a integer you want to test
For example, you can type "java QuadSum dataA 2" 
If there are four distict values that sum up to 2, the program will print "Find unique four values: (5, 1, 2, -6) that add up to 2"
If there are no four distict values that sum up to 2, the program will print "there is no four distict number that sums to 2"

